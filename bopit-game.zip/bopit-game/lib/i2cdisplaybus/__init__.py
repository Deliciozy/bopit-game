# __init__.py for i2cdisplaybus
# Simple shim so "import i2cdisplaybus" works in CircuitPython 10.x
from .i2cdisplaybus import I2CDisplayBus
